﻿#include <iostream>
#include <windows.h>
#include <conio.h>
#include <mmsystem.h>
using namespace std;

HANDLE hConsoleColor;

void gotoxy(int column, int line)

{

    COORD coord;

    coord.X = column;

    coord.Y = line;

    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

}

void Nocursortype()
{
	CONSOLE_CURSOR_INFO Info;
	Info.bVisible = FALSE;
	Info.dwSize = 20;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &Info);
}
int move() {

    char c = _getch();

    if ((int)c == -32) c = _getch();

    switch ((int)c) {

    case 80:
        return 1; //cout << "Xuong";

    case 72:
        return 2; //cout << "Len";

    case 77:
        return 3; //cout << "Phai";       

    case 75:
        return 4; //cout << "Trai";

    case 27:
        return 8; //Nut ESC thoat

    case 13:
        return 5; //Nut Enter

    default:
        return 0; //cout << "Sai";

    }

}
void Mainmenu() {
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "         ";
	cout << "/--------------------------------------------------------------------------------------------------\\" << "         " << endl;
	cout << "         ";
	cout << "| ";
	//line1
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "  |" << "         " << endl;
	//line2
	cout << "         ";
	cout << "| ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "  |" << "         " << endl;
	//line3
	cout << "         ";
	cout << "| ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "  |" << "         " << endl;
	//line4
	cout << "         ";
	cout << "| ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "       ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@@";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "  |" << "         " << endl;
	//line5
	cout << "         ";
	cout << "| ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "  |" << "         " << endl;
	//line6
	cout << "         ";
	cout << "| ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << " |" << "         " << endl;
	cout << "         ";
	cout << "\\--------------------------------------------------------------------------------------------------/" << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                                                                                      " << endl;
	cout << "                                                                                                                      " << endl;
	cout << "                                                                                                                      " << endl;
	//1
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@@@@@@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                                                        " << endl;
	//2
	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                                                      " << endl;
	//3
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                                                      " << endl;
	//4
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "          " << endl;

	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##########";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "        " << endl;

	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 221);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                     ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;

	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 85);
	cout << "@@@@@@@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "**********";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;

	cout << "         ";
	cout << "                                                     ";
	cout << "           ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;

	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	cout << "                             ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;

	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "   ";
	cout << "                             ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##########";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;

	//11
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;
	//12
	cout << "         ";
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "      " << endl;
	//13
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << " ";
	cout << "                             ";
	//line10
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "          " << endl;
	//14
	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 204);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                                                    " << endl;
	//15
	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                                                      " << endl;
	cout << "                                                                                                                      " << endl


		<< "                                                                                                                      " << endl;

}
void newgame() {
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl;
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                           ";
	cout << "                                                         " << "         " << endl;
	//1
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "################################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        " << endl;
	//2
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	cout << "                        ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//3
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%%%%%%%%%%%%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;

	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//5
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//6
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "ww";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//7
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "ww";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                ";
	cout << "       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	cout << "               ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "@@@@@@@@@@";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//10
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "########";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "rr";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "cc";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//11
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "yy";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "cc";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//12
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "rr";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "yy";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "yy";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^^^^^^^^^^^^^^^^^^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      " << endl;
	//13
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "cc";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "rr";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%%%%%%%%%%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        " << endl;
	//14
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	cout << "                                       ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << endl;

	//15
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "yy";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 68);
	cout << "rr";
	SetConsoleTextAttribute(hConsoleColor, 170);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << endl;
	//16
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!!!!!!!";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << endl;
	//17
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << endl;
	//18
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 51);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << endl;


	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "&&&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        ";
	cout << "             ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                " << endl;
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "**";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                " << endl;
	//21
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "****";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                " << endl;
	//22
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";


	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                       ";
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                  " << endl;
	cout << "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl
		<< "                                                                                                                      " << endl;



}
void settings(){
	cout << "         ";
	cout << "          /-------------------------------------------------------------------------------\\         " << "         " << endl;
	//1
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            " << "         " << endl;
	//2
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << "         " << endl;
	//3
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            " << "         " << endl;
	//4
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            " << "         " << endl;
	//5
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            " << "         " << endl;
	//6
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "              " << "         " << endl;
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "         ";
	cout << "          \\-------------------------------------------------------------------------------/         " << "         " << endl;

	//1 	
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!!!!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                                     " << "         " << endl;
	//2
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                                   " << "         " << endl;
	//3
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                           " << "         " << endl;
	//4
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                         " << "         " << endl;
	//5
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                       " << "         " << endl;
	//6
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                       " << "         " << endl;
	//7
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                       ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "       ";
	cout << "ON                  " << "         " << endl;
	//8
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                     " << "         " << endl;
	//9
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 153);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                   " << "         " << endl;
	//10
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&&&&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                   " << "         " << endl;
	//11
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&&&&&&&&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                   " << "         " << endl;
	//12
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&&&&&&&&&&&";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^";
	SetConsoleTextAttribute(hConsoleColor, 34);
	cout << "!!";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "     ";

	cout << "ON                        " << "         " << endl;

	//13
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&&&&&&&";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                   " << "         " << endl;
	//15
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "                              ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                     " << "         " << endl;
	//16
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "                ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                       " << "         " << endl;
	//17
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "              ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                       " << "         " << endl;
	//18
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 187);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          ";
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                         " << "         " << endl;
	//19
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "        ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 119);
	cout << "^^^^^^^^^^";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                         " << "         " << endl;
	//20
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "%%%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                           " << "         " << endl;
	//21
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                  ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 136);
	cout << "%%%%%%%%%%";
	SetConsoleTextAttribute(hConsoleColor, 17);
	cout << "@@";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                  " << endl;
	//22
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "&&&&&&&&&&";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                                     " << "         " << endl;
}
void credits() {	//1 
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####################################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "            ";
	cout << "                    " << "         " << endl;
	//2
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                            " << "         " << endl;
	//3
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          " << "         " << endl;
	//4
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 96);
	cout << "Group 9 - Program technicques";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "###";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        " << "         " << endl;
	//5
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      " << "         " << endl;
	//6
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                        ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      " << "         " << endl;
	//7
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//8
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;

	//9
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//10
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "Nguyen Quoc Thang - 2212738";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << endl;
	//11
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "Nguyen Dinh Kien - 22127216";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "        ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//12
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "Nguyen Gia Nguyen - 22127301";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "       ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//13
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "       ";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "Nguyen Tran Duc Thien - 22127397";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "     ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//14
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//15
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//16
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//17
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "           ";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "GVHD. Truong Toan Thinh";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//18
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//19
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//20
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//21
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//22
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
	//23
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                        ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      " << "         " << endl;
	//24
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      " << "         " << endl;
	//25
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####################################";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        " << "         " << endl;
	//26
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          " << "         " << endl;
	//27
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                            ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                    ";
	SetConsoleTextAttribute(hConsoleColor, 238);
	cout << "                ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                            " << "         " << endl;
	//28
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####################################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                " << "         " << endl;


	cout << "         ";
	cout << "                      ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "                                                        ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                      " << "         " << endl;
	cout << "                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 0);
	cout << "                                                            ";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                    " << "         " << endl;
}
void helps() {
	cout << "                                                                                                    " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                    " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                  " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                              ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "################################";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "                                  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    W - up arrow:             UP    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    A - left arrow:         LEFT      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    S - down arrow:         DOWN        ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    D - right arrow:       RIGHT        ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                        " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    Enter:          CONFIRM MOVE      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                          " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ESC:                   PAUSE    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "                                  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                              ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "################################";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "  ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                          ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                  " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                         ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "               ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                       ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "#################################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                     ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "                             ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                   ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "                     ";
	cout << "BACK";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "      ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                     ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "                             ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                       ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "#################################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                         ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "               ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                  " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                          ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                  " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "         ";
	cout << "                                          ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "##";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                  " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                        ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                                " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                      ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "    ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "######";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                              " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 224);
	cout << "            ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                    ";
	cout << "         ";
	SetConsoleTextAttribute(hConsoleColor, 102);
	cout << "####################";
	SetConsoleTextAttribute(hConsoleColor, 255);
	cout << "                                            " << "         " << endl;

	cout << "                                                                                                    " << endl;

}

class Menu {

public:

    Menu();

    ~Menu() {}

    void printMenu();

    void deleteMenu(); //Xóa menu khi kết thúc chương trình bằng cách viết đè kí tự trắng

    int numberOfItem() {
        return _numberOfItem;
    }

    string* getItem() {
        return item;
    }

private:

    string* item; //Mảng lưu tên của các menu

    int _numberOfItem; //Số lượng menu

};
Menu::Menu() {

    item = new string[100];

    _numberOfItem = 6;

    item[0] = "NEW GAME";

    item[1] = "LOAD GAME";

    item[2] = "SETTINGS";

    item[3] = "CREDITS ";

    item[4] = "HELPS";
	 
	item[5] = "EXIT";

}
void Menu::printMenu() {
	Mainmenu();
	SetConsoleTextAttribute(hConsoleColor, 240);
    for (int i = 0+14; i < _numberOfItem+14; i++) {

        gotoxy(55, i);

		cout << item[i-14] << endl;

        Sleep(100); //Tạm dừng 100ms

    }
}
void Menu::deleteMenu() {

    for (int i = 0; i < 30; i++) {

        Sleep(30);

        gotoxy(0, i);

        for (int j = 0; j < 119; j++) {
            cout << " "; //Xóa bằng cách ghi đè kí tự trắng

        }

    }

}

class NewGameMenu {
public:

	NewGameMenu();

	~NewGameMenu() {}

	void printMenu();

	void deleteMenu(); //Xóa menu khi kết thúc chương trình bằng cách viết đè kí tự trắng

	int numberOfItem() {
		return _numberOfItem;
	}

	string* getItem() {
		return item;
	}

private:

	string* item; //Mảng lưu tên của các menu

	int _numberOfItem; //Số lượng menu

};
NewGameMenu::NewGameMenu() {
	item = new string[100];

	_numberOfItem = 3;

	item[0] = "SINGLEPLAYER (PvB)";

	item[1] = "MULTIPLAYER (PvP)";

	item[2] = "      BACK        ";

};
void NewGameMenu::printMenu() {
	newgame();
	SetConsoleTextAttribute(hConsoleColor, 240);
	gotoxy(48, 6);
	cout << item[0] << endl;
	Sleep(100);
	gotoxy(48, 6+5);
	cout << item[1] << endl;
	Sleep(100);
	gotoxy(48, 6+5 +5);
	cout << item[2] << endl;
	Sleep(100);
}
void NewGameMenu::deleteMenu() {

	for (int i = 0; i < 30; i++) {

		Sleep(10);

		gotoxy(0, i);

		for (int j = 0; j < 119; j++) {
			cout << " "; //Xóa bằng cách ghi đè kí tự trắng

		}

	}

}
void NewGame(int &pmode, int m, int s) {
	NewGameMenu newGame;
	int x_NG;
	int line_NG = 6;
	bool BACK_NG = false;
	newGame.printMenu();
	SetConsoleTextAttribute(hConsoleColor, 240);
	gotoxy(45, line_NG);
	cout << ">";
	while (!BACK_NG) {
		if (_kbhit()) {
			x_NG = move();
			gotoxy(45, line_NG);
			SetConsoleTextAttribute(hConsoleColor, 255);
			cout << " "; //Xóa con trỏ ở vị trí cũ
			SetConsoleTextAttribute(hConsoleColor, 240);
			switch (x_NG) {
			case 1:if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
			case 3:
			{
				if (s % 2 == 0)
					PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
				line_NG+= 5;
				if (line_NG >= newGame.numberOfItem()+5 +5 + 6) line_NG = 6;
				break;
			}
			case 2:if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
			case 4:
			{
				if (s % 2 == 0)
					PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
				line_NG-= 5;
				if (line_NG < 6) line_NG = newGame.numberOfItem() - 1 + 6 +3 +5;
				break;
			}

			case 5:
			{
				if (s % 2 == 0)
					PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
				if (line_NG == 5 + 6+5) BACK_NG = true;
				break;
			}
			}
			gotoxy(45, line_NG);
			SetConsoleTextAttribute(hConsoleColor, 240);
			cout << ">";
		}
	}
	pmode = line_NG;
}

class Settings {
public:

	Settings();

	~Settings() {}

	void printMenu();


	int numberOfItem() {
		return _numberOfItem;
	}

	string* getItem() {
		return item;
	}

private:

	string* item; //Mảng lưu tên của các menu

	int _numberOfItem; //Số lượng menu

};
Settings::Settings() {
	item = new string[100];
	_numberOfItem = 3;
	item[0] = "MUSIC: ";
	item[1] = "  SFX: ";
	item[2] = "  BACK";
}
void Settings::printMenu() {
	settings();
	SetConsoleTextAttribute(hConsoleColor, 240);
	gotoxy(79, 14);
	cout << item[0] << endl;
	Sleep(10);
	gotoxy(79, 14 + 5);
	cout << item[1] << endl;
	Sleep(10);
	gotoxy(79, 14 + 5 + 5);
	cout << item[2] << endl;
	Sleep(10);
}

void SETTINGS(int &m, int &s) {
	Settings set;
	int x_SET;
	bool BACK_SET = false;
	int line_SET = 14;
	set.printMenu();
	if (m % 2 == 0) {
		gotoxy(88, 14);
		cout << "ON ";
	}
	else { gotoxy(88, 14); cout << "OFF"; }
	if (s % 2 == 0) {
		gotoxy(88, 19);
		cout << "ON ";
	}
	else { gotoxy(88, 19); cout << "OFF"; }
	gotoxy(76, 14);
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << ">";
	while (!BACK_SET) {
		if (_kbhit) {
			x_SET = move();
			gotoxy(76, line_SET);
			SetConsoleTextAttribute(hConsoleColor, 255);
			cout << " "; //Xóa con trỏ ở vị trí cũ
			SetConsoleTextAttribute(hConsoleColor, 240);
			switch (x_SET) {
			case 1:if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
			case 3:
			{
				if (s % 2 == 0)
					PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
				line_SET+= 5;
				if (line_SET >= set.numberOfItem() + 14+5+5) line_SET = 14;
				break;
			}
			case 2:if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
			case 4:
			{
				if (s % 2 == 0)
					PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
				line_SET-= 5;
				if (line_SET < 14) line_SET = set.numberOfItem() - 1 + 14 + 5 +3;
				break;
			}
			case 5:
			{
				if (s % 2 == 0)
					PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
				if (line_SET == 14) {
					m++;
					if (m % 2 == 0) {
						gotoxy(88, 14);
						cout << "ON ";
					}
					else { gotoxy(88, 14); cout << "OFF"; }
				}
				if (line_SET == 19) {
					s++;
					if (s % 2 == 0) {
						gotoxy(88, 19);
						cout << "ON ";
					}
					else { gotoxy(88, 19); cout << "OFF"; }
				}
				if (line_SET == 14+5+5) BACK_SET = true;
				break;
			}
			}
			gotoxy(76, line_SET);
			SetConsoleTextAttribute(hConsoleColor, 240);
			cout << ">";

		}
	}
 }

void CREDITS(int s) {
	int x_CRE;
	bool BACK_CRE = false;
	int line_CRE = 26;
	credits();
	gotoxy(52, 26);
	SetConsoleTextAttribute(hConsoleColor, 222);
	cout << "RETURN TO MENU";
	SetConsoleTextAttribute(hConsoleColor, 255);
	while (!BACK_CRE) {
		if (_kbhit()) {
			x_CRE = move();
			if (x_CRE == 5) {
				if (s % 2 == 0)
					PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
				BACK_CRE = true;
			}
		}
	}
}

void HELPS(int s) {
	int x_HELP;
	bool BACK_HELP = false;
	int line_HELP = 18;
	helps();
	gotoxy(53, 18);
	SetConsoleTextAttribute(hConsoleColor, 222);
	cout << "BACK";
	SetConsoleTextAttribute(hConsoleColor, 255);
	while (!BACK_HELP) {
		if (_kbhit()) {
			x_HELP = move();
			if (x_HELP == 5) {
				if (s % 2 == 0)
					PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
				BACK_HELP = true;
			}
		}
	}
}

int main()
{
	PlaySound(TEXT("ycg_logo.wav"), NULL, SND_ASYNC);
	int m = 2, s = 2;
	Nocursortype();
    hConsoleColor = GetStdHandle(STD_OUTPUT_HANDLE);
    Menu menu;
    int x;
	int pmode;
    int line = 14; //Vị trí dòng của menu
    bool EXIT = false;
	menu.printMenu();
	Sleep(3000);
	SetConsoleTextAttribute(hConsoleColor, 240);
    gotoxy(53, line);
	cout << ">";

	 //Vẽ con trỏ trỏ tới menu
    while (!EXIT) {
		if (m == 100) m = 2;
		if (s == 100) s = 2;
		if (_kbhit()) {
			x = move();
			gotoxy(53, line );
			SetConsoleTextAttribute(hConsoleColor, 255);
			cout << " "; //Xóa con trỏ ở vị trí cũ
			SetConsoleTextAttribute(hConsoleColor, 240);
			switch (x) {
			case 1:if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
			case 3:
			{if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
				line++;
				if (line >= menu.numberOfItem() +14) line = 14;
				break;
			}
			case 2:if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
			case 4:
			{if (s % 2 == 0)
				PlaySound(TEXT("menu_file_cursor_move.wav"), NULL, SND_ASYNC);
				line--;
				if (line < 14) line = menu.numberOfItem() - 1 +14 ;
				break;
			}
			case 5:
			{	if (s % 2 == 0)
				PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
				if (line == 14) {
					system("cls");
					NewGame(pmode, m, s);
					if (pmode == 5);
					if (pmode == 10);
					system("cls");
					menu.printMenu();
				}
				if (line ==15){}
				if (line == 16) {
					system("cls");
					SETTINGS(m,s);
					system("cls");
					menu.printMenu();
				}
				if (line == 17){
					system("cls");
					HELPS(s);
					system("cls");
					menu.printMenu();
				}
				if (line == 18){
					system("cls");
					CREDITS(s);
					system("cls");
					menu.printMenu();
				}
				if (line == 19) EXIT = true;
				break;
			}
			}
			gotoxy(53, line);
			SetConsoleTextAttribute(hConsoleColor, 240);
			cout << ">";

		}
    }

    menu.deleteMenu();
	gotoxy(55, 14);
	SetConsoleTextAttribute(hConsoleColor, 240);
	cout << "GOODBYE!";
	gotoxy(0, 0);
    return 0;

}